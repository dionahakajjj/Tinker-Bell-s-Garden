<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Tinker Bell's Garden | Home</title>
  <link rel="stylesheet" href="./index.css">
</head>

<body>
  <header>
    <div class="logo">
      <a href="/" class="logo-link" aria-label="Tinker Bell's Garden home">
        <svg width="44" height="44" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
          <path d="M12 2C9 5 4 7 4 11c0 3 3 6 8 9 5-3 8-6 8-9 0-4-5-6-8-9z" fill="#2f9e77" />
        </svg>
        <h1>Tinker Bell's Garden</h1>
      </a>
    </div>
    <nav>
      <li><a href="/"><strong>Home</strong></a></li>
      <li><a href="/flowers/">Flowers</a></li>
      <li><a href="/aboutUs/">About</a></li>
      <li><a href="/contact/">Contact</a></li>
      <li><a href="/login/">Login</a></li>
      <li><a href="/signUp/">Register</a></li>
    </nav>
  </header>
  <main>
    <section class="hero">
      <div class="hero-card">
        <p class="tag" style="background: #fff3e6; color: #c44d1c">
          Be the reason of her smile.
        </p>
        <span class="badge">Fresh · Local · Green</span>
        <h1>Tinker Bell's Garden</h1>
        <p>
          Elegant bouquets, modern arrangements, and botanical gifts in
          vibrant greens and accents. Calm energy, fresh palettes, fast
          delivery.
        </p>
        <div style="display: flex; gap: 10px; margin-top: 16px">
          <a class="pill" href="/flowers/">View products</a>
          <a class="pill secondary" href="/aboutUs/">About us</a>
        </div>
      </div>
      <div class="slider">
        <div class="slide" style="
              background-image: url('https://images.unsplash.com/photo-1483794344563-d27a8d18014e?auto=format&fit=crop&w=1400&q=80');
            ">
          <div class="overlay">
            Spring bouquets with eucalyptus and gold details
          </div>
        </div>
        <div class="slide" style="
              background-image: url('https://images.unsplash.com/photo-1509042239860-f550ce710b93?auto=format&fit=crop&w=1400&q=80');
            ">
          <div class="overlay">Event florals and minimalist decor</div>
        </div>
        <div class="slide" style="
              background-image: url('https://images.unsplash.com/photo-1501004318641-b39e6451bec6?auto=format&fit=crop&w=1400&q=80&sat=-20');
            ">
          <div class="overlay">Botanical gifts and pine-scented candles</div>
        </div>
      </div>
    </section>
    <div class="section-title">
      <h2>Weekly top picks</h2>
    </div>
    <section class="grid">
      <article class="card">
        <img src="/assets/js/images/Emerald Bouquet.jpg" alt="Bouquet" loading="lazy" />
        <h3>Emerald Bouquet</h3>
        <p>White roses, eucalyptus, and brushed gold accents.</p>
        <span class="price">€45</span>
        <button class="pill secondary show-details" data-title="Emerald Bouquet"
          data-desc="A sophisticated arrangement of premium white roses and eucalyptus foliage, accented with gold details.">See
          details</button>
      </article>
      <article class="card">
        <img src="/assets/js/images/Veronica bouque.jpg" alt="Succulent" loading="lazy" />
        <h3>Urban Succulent Trio</h3>
        <p>Set of three succulents in warm terracotta pots.</p>
        <span class="price">€25</span>
        <button class="pill secondary show-details" data-title="Urban Succulent Trio"
          data-desc="Low-maintenance and trendy, these three succulents come in stylish terracotta pots. Perfect for desks or shelves.">See
          details</button>
      </article>
      <article class="card">
        <img src="/assets/js/images/Pine Forest Candle.jpg" alt="Candle" loading="lazy" />
        <h3>Pine Forest Candle</h3>
        <p>Essential pine oils, hand-poured soy, clean burn.</p>
        <span class="price">€18</span>
        <button class="pill secondary show-details" data-title="Pine Forest Candle"
          data-desc="Bring the scent of the forest indoors with this hand-poured soy candle. Features a clean burn and essential pine oils.">See
          details</button>
      </article>
      <article class="card">
        <img src="/assets/js/images/Sunrise Pastels.jpg" alt="Colorful bouquet" loading="lazy" />
        <h3>Sunrise Pastels</h3>
        <p>Ranunculus, peach roses, blush dahlias, airy greenery.</p>
        <span class="price">€52</span>
        <button class="pill secondary show-details" data-title="Sunrise Pastels"
          data-desc="A dreamy mix of soft pastels featuring ranunculus and roses. Guaranteed to brighten anyone's day.">See
          details</button>
      </article>
    </section>
  </main>

  <!-- Modal -->
  <div id="productModal" class="modal">
    <div class="modal-content">
      <span class="close-modal">&times;</span>
      <h2 id="modalTitle"></h2>
      <p id="modalDesc"></p>
    </div>
  </div>

  <footer class="site-footer">
    <div class="footer-inner">
      <p>&copy; 2026 Tinker Bell's Garden — Diona Hakaj & Eliza Halili</p>
      <nav class="footer-nav">
        <a href="/flowers/">Flowers</a> ·
        <a href="/aboutUs/">About</a> ·
        <a href="/contact/">Contact</a>
      </nav>
    </div>
  </footer>

  <script src="./index.js"></script>
</body>

</html>


   
